﻿## Warning | 警告
<div align="center"><p>This repository is fork from herta_kuru!</p>
<p>该仓库源代码魔改自自herta_kuru，源代码版权归原仓库作者所有</p></div>

[ 点我前往原仓库 ｜ bring me to the repository ](https://github.com/duiqt/herta_kuru)

原仓库群聊：

[![Chat on Discord](https://img.shields.io/badge/chat-discord-blue?style=flat&logo=discord)](https://discord.gg/yzkEz6xxdM)
  
# This repository is for Aris
<div align="center"><img src="static/img/hertaa1.gif"></div>

<div align="center"><p>The website for Aris, the cutest Student from BlueArchive!</p>
<p>献给《<del>蔚蓝</del>碧蓝档案》最可爱的爱丽丝酱</p></div>

# Aris Bangkakabang | 爱丽丝摇啊摇 |
[Have a try | 试一下！](https://alan-shangmike.github.io/Sping_Aris_github.io/)

### Code Editer: AlanShang

<a href="https://github.com/Alan-ShangMike/Sping_Aris_github.io/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=Alan-ShangMike/Sping_Aris_github.io" />
</a>

[![Twitter Follow](https://img.shields.io/twitter/follow/AlanShang)](https://twitter.com/AlanShang4427)

### Artist:Sechi

<a href="https://space.bilibili.com/476491780">
  <img src="https://i1.hdslb.com/bfs/face/dea1734b6360af58edd5ba0d0cd5dbad9d05ad17.jpg@240w_240h_1c_1s_!web-avatar-space-header.avif" />
</a>


Aris GIF is from| 爱丽丝 GIF 来源 : [@video](https://www.youtube.com/watch?v=T9F1Wk8DQdg) 

[![Twitter Follow](https://img.shields.io/twitter/follow/@Sechi)](https://twitter.com/sechihyeo)

Contact | 作者联系方式 : [@Sechi](https://sechi.link/) 


The art the relevant copyright of BlueArchive belongs to Nexon/Yostar.

角色版权归Nexon与Yostar所有。
***
# 原仓库及代码贡献者

<a href="https://github.com/duiqt/herta_kuru/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=duiqt/herta_kuru" />
</a>

### Original Inspration

Thanks KawaiiShadowii and his website [tannhauser.moe](https://tannhauser.moe), where our inspirations and the super-original code from. ([#44](https://github.com/duiqt/herta_kuru/issues/44))
